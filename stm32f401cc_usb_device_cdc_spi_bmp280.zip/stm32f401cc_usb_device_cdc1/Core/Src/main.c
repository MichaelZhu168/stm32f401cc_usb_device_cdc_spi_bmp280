/* USER CODE BEGIN Header */
/**
 * it works with BMP280 on 7/31/2021
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "bmp280.h"
#include "usbd_cdc_if.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define DUMMY_BYTE       0x00
#define SPI1_CS_LOW()   HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);  //use PB15 pin as the SPI1 chip select pin
#define SPI1_CS_HIGH()  HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
	  /* there is no SWO header on the my st-link v2 clone,
	   * I can't use the ITM_SendChar
int _write(int file, char *ptr, int len)
{
  int DataIdx;

  for (DataIdx = 0; DataIdx < len; DataIdx++)
  {
    ITM_SendChar(*ptr++);
  }
  return len;
}
----*/
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
uint8_t hasUSBMsgReceived=0;
uint16_t i=0;
uint8_t tempValue_to_host[8];
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t spiTxBuf[10], spiRxBuf[10];

/*----
// 25AA040A EEPRON chip instructions
const uint8_t EEPROM_READ = 0b00000011;
const uint8_t EEPROM_WRITE = 0b00000010;
const uint8_t EEPROM_WRDI = 0b00000100;
const uint8_t EEPROM_WREN = 0b00000110;
const uint8_t EEPROM_RDSR = 0b00000101;
const uint8_t EEPROM_WRSR = 0b00000001;
----*/

//--start of bmp280 variables------
void bmp280_config(void);
void bmp280_get_data(void);
//void delay_ms(uint32_t period_ms);
int8_t spi_reg_write(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
int8_t spi_reg_read(uint8_t cs, uint8_t reg_addr, uint8_t *reg_data, uint16_t length);
uint8_t spi_send_byte(uint8_t byte);
uint8_t spi_read_byte(void);

int8_t rslt;
struct bmp280_dev bmp;
struct bmp280_config conf;
struct bmp280_uncomp_data ucomp_data;
int32_t temp32;
double temp;

uint32_t pres32, pres64;
double pres;

//--end of bmp280 variables------


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	//char counter = 0


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  MX_USB_DEVICE_Init();
  /* USER CODE BEGIN 2 */



  // CS pin should default high
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);  //use PB15 as SPI1 CS pin

	/*--------EEPROM action, code example only----
	// Test bytes to write to EEPROM
	spiTxBuf[0] = 0xAB;
	spiTxBuf[1] = 0xCD;
	spiTxBuf[2] = 0xEF;

    // Set starting address
    uint8_t addr;
	addr = 0x05;

      // Write 3 bytes starting at given address
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET);  //use PB15 as SPI1 CS pin
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&EEPROM_WRITE, 1, 50);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&addr, 1, 50);
	HAL_SPI_Transmit(&hspi1, (uint8_t *)spiTxBuf, 3, 50);
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);

      // Read status register
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_RESET); //use PB15 as SPI1 CS pin
	HAL_SPI_Transmit(&hspi1, (uint8_t *)&EEPROM_RDSR, 1, 50);
	HAL_SPI_Receive(&hspi1, (uint8_t *)spiRxBuf, 1, 50);
	HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);
	-----------EEPROM action, code example only------*/


	//----init BMP280---
	bmp280_config();
	//bmp280_get_data();

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (hasUSBMsgReceived==1)
	  {
		  hasUSBMsgReceived=0;
		  // get data from SPI0/bmp280
		  bmp280_get_data(); //--after this line, the temperature value will be in temp32 (32bits) and temp(64bits)

	      //--start to fill usb_data_buffer_to_host[] with temp32(32bits)--
		  tempValue_to_host[0] = 0x02;
		  tempValue_to_host[1] = 0x93;
		  tempValue_to_host[2] = 68;
	        //tempValue_to_host[2] = result;
		  tempValue_to_host[3] = 0;

		  tempValue_to_host[4] = temp32         & 0xff;
		  tempValue_to_host[5] = (temp32 >> 8)  & 0xff;
		  tempValue_to_host[6] = (temp32 >> 16)  & 0xff;
		  tempValue_to_host[7] = (temp32 >> 24)  & 0xff;
		  CDC_Transmit_FS(tempValue_to_host, 8);
		  /*---
		  i=i+1;
		  if (i%2==0)
		  {
			  //sprintf(tempValue_to_host, "%d", i);  //---convert int to char
			  CDC_Transmit_FS(tempValue_to_host, 4); //---will return '2','4','6',...
		  }
			---*/
	  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE2);
  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 7;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV8;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPI_CS_GPIO_Port, SPI_CS_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin : SPI_CS_Pin */
  GPIO_InitStruct.Pin = SPI_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(SPI_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : EXTI9_Pin */
  GPIO_InitStruct.Pin = EXTI9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(EXTI9_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

}

/* USER CODE BEGIN 4 */
void bmp280_config(void)
{

	    /* Map the delay function pointer with the function responsible for implementing the delay */
	    bmp.delay_ms = HAL_Delay;

	    /* Assign device I2C address based on the status of SDO pin (GND for PRIMARY(0x76) & VDD for SECONDARY(0x77)) */
	    //bmp.dev_id = BMP280_I2C_ADDR_PRIM;

	    /* Select the interface mode as I2C */
	    //bmp.intf = BMP280_I2C_INTF;

	    /* Map the I2C read & write function pointer with the functions responsible for I2C bus transfer */
	    //bmp.read = i2c_reg_read;
	    //bmp.write = i2c_reg_write;

	    /* To enable SPI interface: comment the above 4 lines and uncomment the below 4 lines */

	     bmp.dev_id = 0;
	     bmp.read = spi_reg_read;
	     bmp.write = spi_reg_write;
	     bmp.intf = BMP280_SPI_INTF;

	    rslt = bmp280_init(&bmp);
	    //print_rslt(" bmp280_init status", rslt);

	    /* Always read the current settings before writing, especially when
	     * all the configuration is not modified
	     */
	    rslt = bmp280_get_config(&conf, &bmp);
	    //print_rslt(" bmp280_get_config status", rslt);

	    /* configuring the temperature oversampling, filter coefficient and output data rate */
	    /* Overwrite the desired settings */
	    conf.filter = BMP280_FILTER_COEFF_2;

	    /* Temperature oversampling set at 4x */
	    conf.os_temp = BMP280_OS_4X;

	    /* Pressure over sampling none (disabling pressure measurement) */
	    conf.os_pres = BMP280_OS_NONE;

	    /* Setting the output data rate as 1HZ(1000ms) */
	    conf.odr = BMP280_ODR_1000_MS;
	    rslt = bmp280_set_config(&conf, &bmp);
	    //print_rslt(" bmp280_set_config status", rslt);

	    /* Always set the power mode after setting the configuration */
	    rslt = bmp280_set_power_mode(BMP280_NORMAL_MODE, &bmp);
	    //print_rslt(" bmp280_set_power_mode status", rslt);

}

void bmp280_get_data(void)
{

    // Reading the raw data from sensor
     rslt = bmp280_get_uncomp_data(&ucomp_data, &bmp);

	// Getting the 32 bit compensated temperature
	rslt = bmp280_get_comp_temp_32bit(&temp32, ucomp_data.uncomp_temp, &bmp);

	// Getting the compensated temperature as floating point value
	rslt = bmp280_get_comp_temp_double(&temp, ucomp_data.uncomp_temp, &bmp);
	//printf("UT: %ld, T32: %ld, T: %f \r\n", ucomp_data.uncomp_temp, temp32, temp);

	// Sleep time between measurements = BMP280_ODR_1000_MS
	//bmp.delay_ms(10);
}

/*!
 *  @brief Function for writing the sensor's registers through SPI bus.
 *
 *  @param[in] cs           : Chip select to enable the sensor.
 *  @param[in] reg_addr     : Register address.
 *  @param[in] reg_data : Pointer to the data buffer whose data has to be written.
 *  @param[in] length       : No of bytes to write.
 *
 *  @return Status of execution
 *  @retval 0 -> Success
 *  @retval >0 -> Failure Info
 *
 */
int8_t spi_reg_write(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{

    /* Implement the SPI write routine according to the target machine. */

	int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
	uint8_t cnt = 0;
	SPI1_CS_LOW();    //---set CS(PB15) to low
	//delay_ms(10);  //must have some delay here. Tried. at least 10ms --mzhu
	HAL_Delay(10); //must have some delay here. Tried. at least 10ms --mzhu
    spi_send_byte(reg_addr);
	do
	{
		spi_send_byte(reg_data[cnt]);
		cnt++;
	}while (len > cnt);
	HAL_Delay(10);
	SPI1_CS_HIGH();  //--set CS high--
	return rslt;
}


/*!
 *  @brief Function for reading the sensor's registers through SPI bus.
 *
 *  @param[in] cs       : Chip select to enable the sensor.
 *  @param[in] reg_addr : Register address.
 *  @param[out] reg_data    : Pointer to the data buffer to store the read data.
 *  @param[in] length   : No of bytes to read.
 *
 *  @return Status of execution
 *  @retval 0 -> Success
 *  @retval >0 -> Failure Info
 *
 */
int8_t spi_reg_read(uint8_t dev_id, uint8_t reg_addr, uint8_t *reg_data, uint16_t len)
{

    /* Implement the SPI read routine according to the target machine. */

    int8_t rslt = 0; /* Return 0 for Success, non-zero for failure */
	int8_t cnt = 0;

	SPI1_CS_LOW();    //---set CS(PB15) to low
	HAL_Delay(10);  //must have some delay here. Tried. at least 10ms --mzhu
	spi_send_byte(reg_addr);
	do
	{
		*reg_data = (uint8_t)spi_read_byte();
		reg_data ++;
		cnt++;
	}while (len > cnt);

	HAL_Delay(11);
	SPI1_CS_HIGH(); //--set CS high--

	return rslt;

}

/*!
    \brief      send a byte through the SPI interface and return the byte received from the SPI bus
    \param[in]  byte: byte to send
    \param[out] none
    \retval     the value of the received byte
*/
uint8_t spi_send_byte(uint8_t byte)
{
    //--in full-duplex master mode, in order to get the receive data you must put a data to SPI_DATA first ---mzhu
    /* loop while data register in not emplty */
   // while (RESET == spi_i2s_flag_get(SPI0,SPI_FLAG_TBE));

    /* send byte through the SPI0 peripheral */
   // spi_i2s_data_transmit(SPI0,byte);  //--put the data into SPI_DATA(transmit buffer) register, then the chip will move it to the shift register

    /* wait to receive a byte */
  //  while(RESET == spi_i2s_flag_get(SPI0,SPI_FLAG_RBNE));

    /* return the byte read from the SPI bus */
  //  return(spi_i2s_data_receive(SPI0)); //--get the data from SPI_DATA(also as receive register)


    //return HAL_SPI_Transmit(&hspi1, byte, 1, 50);
	//HAL_SPI_Transmit(&hspi1, &byte, 1, 50);
	//HAL_SPI_Receive(&hspi1, (uint8_t *)spiRxBuf, 1, 50);
	HAL_SPI_TransmitReceive(&hspi1, &byte, (uint8_t *)spiRxBuf, 1, 50);  //---must use this one, otherwise not works.
	return spiRxBuf[0];
}

/*!
    \brief      read a byte from the SPI flash
    \param[in]  none
    \param[out] none
    \retval     byte read from the SPI flash
*/
uint8_t spi_read_byte(void)
{
    return(spi_send_byte(DUMMY_BYTE));
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
